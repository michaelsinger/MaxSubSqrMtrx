import Foundation
import UIKit

//1. Largest Matrix

let arr = [[1,1,1,1,1],
    
    [1,1,1,0,0],
    
    [1,1,1,0,0],
    
    [1,1,1,0,0],
    
    [1,1,1,1,1]]

func largestMatrix(arr: [[Int]]) -> Int {
    //want to keep track of 1's in the param array and increment for each rowXcolumn == 1
    var buffer = arr
    let columns = arr.count
    let rows = arr[0].count
    
    guard rows == columns else {
        print("not a square matrix")
        return 0
    }
    
    //populate first row and column of buffer to avoid out of index error
    for i in 0..<columns {
            buffer[i][0] = arr[i][0]
            buffer[0][i] = arr[0][i]
    }

    //populate remaining rows of buffer and increment counter for rowXcolumn == 1 where immediate neighbors are also 1
    for i in 1..<columns {
        for j in 1..<rows {
            if arr[i][j] > 0 {
                let minTL = min(buffer[(i - 1)][j], buffer[i][(j - 1)])
                let m = min(minTL, buffer[(i - 1)][(j - 1)])
                //only add smallest count for previously evaluated places in matrix to increment
                buffer[i][j] = m + 1
            } else {
                // the evaluated spot is 0, don't increment the count in the buffer
                buffer[i][j] = 0
            }
        }
    }
    
    //check for largest value in buffer
    var max = buffer[0][0]
    for i in 0..<columns {
        for j in 0..<rows {
            if buffer[i][j] > max {
                max = buffer[i][j]
            }
        }
    }
    return max
}

print(largestMatrix(arr: arr))

